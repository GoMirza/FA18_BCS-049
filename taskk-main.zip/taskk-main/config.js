export const firebaseConfig = {
  apiKey: 'AIzaSyDpdzMzr89hfvlfrfmwdXuEGwxS3U6wfGs',
  authDomain: 'car-showroom-a24a1.firebaseapp.com',
  projectId: 'car-showroom-a24a1',
  storageBucket: 'car-showroom-a24a1.appspot.com',
  messagingSenderId: '497005101198',
  appId: '1:497005101198:web:50e83a2b8969bb1a7809df',
};
