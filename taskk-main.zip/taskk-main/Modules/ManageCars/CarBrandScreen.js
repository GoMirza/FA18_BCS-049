import React, {useState} from 'react';

import {View, FlatList, SafeAreaView, ScrollView, Text} from 'react-native';
import AppBtn from '../../res/Buttons/AppBtn';
import SimpleAppHeader from '../../res/Headers/SimpleAppHeader';

import styles from './Style';
const CarBrandScreen = props => {
  return (
    <SafeAreaView>
      <View style={styles.screen}>
        <SimpleAppHeader title="Car Brands"></SimpleAppHeader>
        <ScrollView>
          <View>
            <Text>Car Brands Screen</Text>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};
export default CarBrandScreen;
