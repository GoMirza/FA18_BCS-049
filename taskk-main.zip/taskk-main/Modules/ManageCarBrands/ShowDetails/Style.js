import {StyleSheet} from 'react-native';
export default StyleSheet.create({
  screen: {
    height: '100%',
    width: '100%',
    justifyContent: 'center',

    backgroundColor: '#FFFFFF',
  },
  image: {
    width: '100%',
    height: 230,

    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
});
