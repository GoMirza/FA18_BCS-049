import React, {useState} from 'react';

import {View, Image, SafeAreaView, ScrollView, Text} from 'react-native';
import AppBtn from '../../../res/Buttons/AppBtn';
import SimpeAppHeader from '../../../res/Headers/SimpleAppHeader';

import styles from './Style';
const DetailScreen = props => {
  console.log(props.route.params.item.uri);
  const navigation = () => {
    props.navigation.goBack();
  };
  return (
    <SafeAreaView>
      <View style={styles.screen}>
        <SimpeAppHeader title="Car Details"></SimpeAppHeader>
        <ScrollView>
          <View style={styles.card}>
            <Image
              style={styles.image}
              source={{uri: props.route.params.item.uri}}
            />
          </View>
          <View
            style={{
              marginVertical: 10,
              aligSelf: 'center',
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <Text style={{fontSize: 18, fontWeight: 'bold'}}>
              Modal : {props.route.params.item.Modal}
            </Text>
            <Text style={{fontSize: 18, fontWeight: 'bold'}}>
              Make : {props.route.params.item.make}
            </Text>
          </View>

          <AppBtn title="Return" onpress={navigation}></AppBtn>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};
export default DetailScreen;
