import React, {useState} from 'react';

import {View, FlatList, SafeAreaView, ScrollView, Text} from 'react-native';
import AppBtn from '../../../res/Buttons/AppBtn';
import AppHeader from '../../../res/Headers/AppHeader';
import SimpleAppHeader from '../../../res/Headers/SimpleAppHeader';

import styles from './Style';
const NewCarScreen = props => {
  return (
    <SafeAreaView>
      <View style={styles.screen}>
        <SimpleAppHeader title="Car Features"></SimpleAppHeader>
        <ScrollView>
          <View>
            <Text>New Car Screen</Text>
            <AppBtn title="Add Car"></AppBtn>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};
export default NewCarScreen;
