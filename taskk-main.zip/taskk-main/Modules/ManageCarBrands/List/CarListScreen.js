import React, {useState, useEffect} from 'react';
import {
  View,
  FlatList,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Image,
  Text,
} from 'react-native';
import AppBtn from '../../../res/Buttons/AppBtn';
import * as firebase from 'firebase';
import AppHeader from '../../../res/Headers/AppHeader';
import {firebaseConfig} from '../../../config';
import styles from './Style';
const CarListScreen = props => {
  useEffect(() => {
    const myitems = firebase.database().ref('items');
    myitems.on('value', data => {
      console.log('Firebase Data===>', data.val());
    });
  });
  firebase.initializeApp(firebaseConfig);
  const images = [
    {
      make: 'Toyota',
      Modal: 'Corolla',
      uri: 'https://images.pexels.com/photos/733745/pexels-photo-733745.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260',
    },
    {
      make: 'Toyota',
      Modal: 'Corolla',
      uri: 'https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
      make: 'Toyota',
      Modal: 'Corolla',
      uri: 'https://images.pexels.com/photos/2365572/pexels-photo-2365572.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
      make: 'Toyota',
      Modal: 'Corolla',
      uri: 'https://images.pexels.com/photos/4083525/pexels-photo-4083525.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
    },
  ];

  const navigation = item => {
    props.navigation.navigate('DetailScreen', {
      item,
    });
  };
  const navigateToAddNewCar = () => {
    props.navigation.navigate('NewCarScreen');
  };
  return (
    <SafeAreaView>
      <View style={styles.screen}>
        <AppHeader
          title="List of Cars"
          onpress={navigateToAddNewCar}></AppHeader>

        <View style={{height: '90%'}}>
          <FlatList
            style={styles.flatListStyle}
            data={images}
            keyExtractor={item => {
              item.index;
            }}
            renderItem={({item}) => {
              return (
                <TouchableOpacity
                  onPress={() => {
                    navigation(item);
                  }}
                  style={{
                    flex: 1,
                    marginVertical: 5,
                    borderColor: 'red',
                    marginHorizontal: 1,
                  }}>
                  <Image style={styles.image} source={{uri: item.uri}} />
                  <View style={styles.txtContainer}>
                    <Text>Modal: {item.Modal}</Text>
                    <Text>Make: {item.make}</Text>
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};
export default CarListScreen;
