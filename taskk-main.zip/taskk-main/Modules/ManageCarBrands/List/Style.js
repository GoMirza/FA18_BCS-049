import {StyleSheet} from 'react-native';
export default StyleSheet.create({
  screen: {
    height: '100%',
    width: '100%',
    justifyContent: 'center',

    backgroundColor: '#FFFFFF',
  },
  flatListStyle: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: 230,
    borderRadius: 20,
  },
  txtContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 20,
    marginTop: 10,
  },
});
