import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import {Icon} from 'react-native-elements/dist/icons/Icon';
const AppHeader = props => {
  return (
    <View style={styles.container}>
      <Text style={styles.headertextstyle}>{props.title}</Text>
      <Icon
        onPress={() => {
          props.onpress();
        }}
        name="add"
        color="white"
        size={24}
        containerStyle={styles.iconContainer}></Icon>
    </View>
  );
};
const styles = StyleSheet.create({
  iconContainer: {
    marginEnd: 15,
  },
  container: {
    height: '10%',

    flexDirection: 'row',
    backgroundColor: 'rgba(30,30,30,1)',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headertextstyle: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 20,
    marginStart: 15,
    alignSelf: 'center',
  },
});
export default AppHeader;
