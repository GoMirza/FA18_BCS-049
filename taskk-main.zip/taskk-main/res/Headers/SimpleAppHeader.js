import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
const SimpleAppHeader = props => {
  return (
    <View style={styles.container}>
      <Text style={styles.headertextstyle}>{props.title}</Text>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    height: '10%',
    backgroundColor: 'rgba(30,30,30,1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headertextstyle: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 20,
    marginStart: 15,
    alignSelf: 'center',
  },
});
export default SimpleAppHeader;
