export default Color = {
  primary: '#761889',
  secondary: '#86E221',
};
