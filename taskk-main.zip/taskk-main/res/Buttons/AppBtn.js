import React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';
const AppBtn = props => {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => {
        props.onpress();
      }}>
      <Text style={styles.titletextstyle}>{props.title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#761889',
    height: 50,
    borderColor: 'blue',
    borderWidth: 1,
    alignSelf: 'center',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titletextstyle: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 18,
    marginHorizontal: 20,
  },
});
export default AppBtn;
