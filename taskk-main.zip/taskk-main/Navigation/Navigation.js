import React, {useState} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import CarListScreen from '../Modules/ManageCarBrands/List/CarListScreen';
import DetailScreen from '../Modules/ManageCarBrands/ShowDetails/DetailScreen';
import NewCarScreen from '../Modules/ManageCarBrands/AddNewCar/NewCarScreen';
import CarBrandScreen from '../Modules/ManageCars/CarBrandScreen';
const Stack = createStackNavigator();
const BrandStack = createStackNavigator();
const Drawer = createDrawerNavigator();
const ShowRoomCarScreens = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="CarListScreen"
        component={CarListScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="DetailScreen"
        component={DetailScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="NewCarScreen"
        component={NewCarScreen}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
const BrandCarScreen = () => {
  return (
    <BrandStack.Navigator>
      <BrandStack.Screen
        name="CarBrandScreen"
        component={CarBrandScreen}
        options={{headerShown: false}}></BrandStack.Screen>
    </BrandStack.Navigator>
  );
};
const MainNavigator = () => {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Manage Cars">
        <Drawer.Screen name="Manage Cars" component={ShowRoomCarScreens} />
        <Drawer.Screen name="Car Brands" component={BrandCarScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
};
export default MainNavigator;
